#include "kernel/types.h"
#include "user/user.h"

/*
  Assignment: P2
  Names: Carissa Kiehl & Noah Wilson
  Date: 9/27/23
*/

int
main(int argc, char *argv[])
{
  printf("The number of live processes: %d\n",count());
  exit(0);
}


