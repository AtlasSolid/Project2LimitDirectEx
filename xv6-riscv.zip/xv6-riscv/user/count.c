#include "kernel/types.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
  printf("The number of live processes: %d\n",count());
  exit(0);
}


